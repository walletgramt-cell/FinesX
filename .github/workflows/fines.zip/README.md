# FinesX Messenger

Красивый Android-мессенджер на Kotlin + Jetpack Compose.

## Уже есть
- FinesX branding
- тёмный современный интерфейс
- регистрация/вход по номеру телефона через Firebase Authentication
- автоматический вход после подтверждения
- экран чатов
- контакты и профиль
- выход из аккаунта

## Что нужно настроить
1. Создай проект в Firebase Console.
2. Добавь Android-приложение с package name:
   `com.finesx.messenger`
3. Скачай `google-services.json` и положи его в:
   `app/google-services.json`
4. В Firebase Authentication включи Phone.
5. Для реального обмена сообщениями подключи Firestore и создай нужные Security Rules.

## APK
Для release APK используй Android Studio:
Build -> Generate Signed App Bundle / APK -> APK.

Для подписи создай отдельный keystore и НЕ публикуй его и пароли в GitHub.
В `app/build.gradle.kts` уже оставлен шаблон signingConfigs.
