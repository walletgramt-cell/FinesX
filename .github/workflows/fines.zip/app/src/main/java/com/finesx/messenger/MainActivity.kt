package com.finesx.messenger

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF080B14)
private val Card = Color(0xFF121827)
private val Accent = Color(0xFF7C5CFF)
private val Accent2 = Color(0xFF19D3AE)
private val TextPrimary = Color(0xFFF6F7FB)
private val TextMuted = Color(0xFF9299AA)

data class Chat(val id: String, val name: String, val preview: String, val time: String)

class MainActivity : ComponentActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FinesXApp() }
    }

    @Composable
    private fun FinesXApp() {
        var screen by remember { mutableStateOf(if (auth.currentUser == null) "auth" else "home") }
        var verificationId by remember { mutableStateOf<String?>(null) }
        var phone by remember { mutableStateOf("") }
        var code by remember { mutableStateOf("") }
        var loading by remember { mutableStateOf(false) }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Bg,
                surface = Card,
                primary = Accent,
                secondary = Accent2,
                onBackground = TextPrimary,
                onSurface = TextPrimary
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = Bg) {
                when (screen) {
                    "auth" -> PhoneAuthScreen(
                        phone = phone,
                        code = code,
                        codeSent = verificationId != null,
                        loading = loading,
                        onPhoneChange = { phone = it },
                        onCodeChange = { code = it },
                        onSendCode = {
                            loading = true
                            val options = PhoneAuthOptions.newBuilder(auth)
                                .setPhoneNumber(phone.trim())
                                .setTimeout(60L, TimeUnit.SECONDS)
                                .setActivity(this)
                                .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                    override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                                        auth.signInWithCredential(credential).addOnCompleteListener {
                                            loading = false
                                            if (it.isSuccessful) screen = "home"
                                        }
                                    }

                                    override fun onVerificationFailed(e: Exception) {
                                        loading = false
                                        Toast.makeText(this@MainActivity, e.message ?: "Ошибка", Toast.LENGTH_LONG).show()
                                    }

                                    override fun onCodeSent(
                                        id: String,
                                        token: PhoneAuthProvider.ForceResendingToken
                                    ) {
                                        verificationId = id
                                        loading = false
                                    }
                                }).build()
                            PhoneAuthProvider.verifyPhoneNumber(options)
                        },
                        onVerify = {
                            val id = verificationId ?: return@PhoneAuthScreen
                            loading = true
                            val credential = PhoneAuthProvider.getCredential(id, code.trim())
                            auth.signInWithCredential(credential).addOnCompleteListener {
                                loading = false
                                if (it.isSuccessful) screen = "home"
                                else Toast.makeText(this@MainActivity, "Неверный код", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                    else -> HomeScreen(
                        onLogout = {
                            auth.signOut()
                            screen = "auth"
                            verificationId = null
                            phone = ""
                            code = ""
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PhoneAuthScreen(
    phone: String,
    code: String,
    codeSent: Boolean,
    loading: Boolean,
    onPhoneChange: (String) -> Unit,
    onCodeChange: (String) -> Unit,
    onSendCode: () -> Unit,
    onVerify: () -> Unit
) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF11152A), Bg))
        )
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier.size(88.dp).clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Accent, Accent2))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Forum, null, tint = Color.White, modifier = Modifier.size(44.dp))
            }

            Spacer(Modifier.height(22.dp))
            Text("FinesX", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            Text("Общайся. Быстро. Красиво. Без лишнего.", color = TextMuted, fontSize = 14.sp)

            Spacer(Modifier.height(42.dp))

            if (!codeSent) {
                Text("Вход по номеру телефона", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = onPhoneChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Номер телефона") },
                    placeholder = { Text("+49 123 456789") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Phone, null) },
                    shape = RoundedCornerShape(18.dp)
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onSendCode,
                    enabled = phone.isNotBlank() && !loading,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    if (loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Text("Получить код", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Text("Введите код", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Код отправлен на $phone", color = TextMuted)
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { if (it.length <= 6) onCodeChange(it) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Код подтверждения") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Lock, null) },
                    shape = RoundedCornerShape(18.dp)
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onVerify,
                    enabled = code.length >= 6 && !loading,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    if (loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Text("Войти в FinesX", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(22.dp))
            Text(
                "Продолжая, вы соглашаетесь с правилами FinesX",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun HomeScreen(onLogout: () -> Unit) {
    var selected by remember { mutableIntStateOf(0) }
    val chats = remember {
        listOf(
            Chat("1", "FinesX Team", "Добро пожаловать в FinesX 👋", "сейчас"),
            Chat("2", "Алекс", "Увидимся вечером", "12:42"),
            Chat("3", "Design Group", "Новый макет уже готов", "11:20")
        )
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0E1320)) {
                NavigationBarItem(
                    selected = selected == 0,
                    onClick = { selected = 0 },
                    icon = { Icon(Icons.Default.Chat, null) },
                    label = { Text("Чаты") }
                )
                NavigationBarItem(
                    selected = selected == 1,
                    onClick = { selected = 1 },
                    icon = { Icon(Icons.Default.People, null) },
                    label = { Text("Контакты") }
                )
                NavigationBarItem(
                    selected = selected == 2,
                    onClick = { selected = 2 },
                    icon = { Icon(Icons.Default.Person, null) },
                    label = { Text("Профиль") }
                )
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (selected == 0) {
                Row(
                    Modifier.fillMaxWidth().padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("FinesX", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Ваши сообщения", color = TextMuted)
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Search, "Поиск")
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Edit, "Новое сообщение")
                    }
                }

                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    items(chats) { chat ->
                        ChatRow(chat)
                    }
                }
            } else if (selected == 1) {
                CenterPage("Контакты", Icons.Default.People)
            } else {
                CenterPage("Профиль", Icons.Default.Person)
                TextButton(
                    onClick = onLogout,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text("Выйти из аккаунта", color = Color(0xFFFF6B7A))
                }
            }
        }
    }
}

@Composable
fun ChatRow(chat: Chat) {
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable {}
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent, Accent2))),
            contentAlignment = Alignment.Center
        ) {
            Text(chat.name.take(1), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(chat.preview, color = TextMuted, maxLines = 1)
        }
        Text(chat.time, color = TextMuted, fontSize = 11.sp)
    }
}

@Composable
fun CenterPage(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, modifier = Modifier.size(60.dp), tint = Accent)
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Раздел FinesX", color = TextMuted)
    }
}
